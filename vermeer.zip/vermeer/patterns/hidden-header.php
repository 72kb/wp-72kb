<?php
/**
 * Title: Header
 * Slug: vermeer/hidden-header
 * Categories: hidden
 * Inserter: no
 */
?>

<!-- wp:site-title {"style":{"color":{"text":"#ffffff"},"elements":{"link":{"color":{"text":"#ffffff"}}},"spacing":{"padding":{"top":"16px"},"margin":{"top":"0","bottom":"0"}}},"className":"is-style-vermeer-marquee-left"} /-->